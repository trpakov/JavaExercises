
public class BankProgram {

	public static void main(String[] args) {
		BankClient client = new BankClient();
		client.run();

	}

}
